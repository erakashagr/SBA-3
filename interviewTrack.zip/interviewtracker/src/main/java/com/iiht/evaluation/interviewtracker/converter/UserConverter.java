package com.iiht.evaluation.interviewtracker.converter;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;


import com.iiht.evaluation.interviewtracker.dto.UserDto;

import com.iiht.evaluation.interviewtracker.entity.User;

@Component
public class UserConverter {
	public UserDto entityToDto(User user)
	{
		UserDto userDto=new UserDto();
		userDto.setUserId(user.getId());
		userDto.setFirstName(user.getFirstName());
		userDto.setLastName(user.getLastName());
		userDto.setEmail(user.getEmail());
		userDto.setMobile(user.getMobile());	
		return userDto;
		
	}
	
	public List<UserDto> entityToDto(List<User> users)
	{
		return users.stream().map(x->entityToDto(x)).collect(Collectors.toList());
		
	}
	
	public User dtoToEntity(UserDto userDto)
	{
		User user=new User();
		user.setId(userDto.getUserId());
		user.setFirstName(userDto.getFirstName());
		user.setLastName(userDto.getLastName());
		user.setEmail(userDto.getEmail());
		user.setMobile(userDto.getMobile());
			
		return user;
		
	}
	
	public List<User> dtoToEntity(List<UserDto> dtos)
	{
		return dtos.stream().map(x->dtoToEntity(x)).collect(Collectors.toList());
	}
	

}
