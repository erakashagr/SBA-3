package com.iiht.evaluation.interviewtracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterviewTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterviewTrackerApplication.class, args);
	}

}
