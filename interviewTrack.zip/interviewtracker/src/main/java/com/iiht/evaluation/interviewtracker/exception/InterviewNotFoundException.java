package com.iiht.evaluation.interviewtracker.exception;

public class InterviewNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InterviewNotFoundException(String message) {
		super(message);
	}
}
