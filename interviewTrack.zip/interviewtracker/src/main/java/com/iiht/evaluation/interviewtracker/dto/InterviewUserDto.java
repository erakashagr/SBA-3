package com.iiht.evaluation.interviewtracker.dto;

public class InterviewUserDto {
	private long interviewId;
	private long userId;
	
	public long getInterviewId() {
		return interviewId;
	}
	public void setInterviewId(long interviewId) {
		this.interviewId = interviewId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	

}
